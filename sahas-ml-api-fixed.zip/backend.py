# backend.py
from fastapi import FastAPI
import pandas as pd
import os

app = FastAPI(title="Village API")

ART_DIR = os.getenv("ART_DIR", "./artifacts")
VILLAGES_FILE = os.path.join(ART_DIR, "villages_master.csv")

# Load dummy data
if os.path.exists(VILLAGES_FILE):
    villages_df = pd.read_csv(VILLAGES_FILE)
else:
    villages_df = pd.DataFrame([{"id": 1, "name": "Sample Village", "district": "Test"}])

@app.get("/api/v1/villages")
def get_villages():
    return villages_df.to_dict(orient="records")

@app.get("/api/v1/village/{village_id}")
def get_village(village_id: int):
    row = villages_df[villages_df["id"] == village_id]
    if row.empty:
        return {"error": "Village not found"}
    return row.iloc[0].to_dict()
