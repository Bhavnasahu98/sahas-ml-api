# SAHAS ML API Deployment (Render)

## Start Command (Render)
Use this simple command (works on free tier):

```
uvicorn main_app:app --host 0.0.0.0 --port $PORT
```

Alternative (gunicorn with workers):

```
gunicorn -k uvicorn.workers.UvicornWorker main_app:app --bind 0.0.0.0:$PORT --workers 2
```
