# ingest_app.py
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Ingest API")

class Report(BaseModel):
    person_id: str
    symptoms: dict
    village_id: int

reports_db = []

@app.post("/api/v1/reports")
def receive_report(report: Report):
    reports_db.append(report.dict())
    return {"status": "received", "count": len(reports_db)}
