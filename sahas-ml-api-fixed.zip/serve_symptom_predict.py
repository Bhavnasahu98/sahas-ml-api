# serve_symptom_predict.py
from fastapi import FastAPI
from pydantic import BaseModel
import os
import joblib
import json

app = FastAPI(title="Symptom Prediction API")

ART_DIR = os.getenv("ART_DIR", "./artifacts")
MODEL_PATH = os.path.join(ART_DIR, "dummy_model.pkl")
INDEX_PATH = os.path.join(ART_DIR, "model_index.json")

# Dummy model + labels
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)
else:
    model = None

if os.path.exists(INDEX_PATH):
    with open(INDEX_PATH, "r") as f:
        model_index = json.load(f)
else:
    model_index = {"0": "Diarrhea", "1": "Typhoid", "2": "Fever"}

class SymptomInput(BaseModel):
    person_id: str
    age: int
    sex_male: int
    fever: int
    diarrhea: int
    vomiting: int
    free_text: str = ""

@app.post("/predict/symptoms")
def predict_symptoms(inp: SymptomInput):
    # In real use: vectorize + model.predict_proba()
    # Here we simulate output
    probs = {disease: round(1/len(model_index), 3) for disease in model_index.values()}
    return {"person_id": inp.person_id, "probabilities": probs}
