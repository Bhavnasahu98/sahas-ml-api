# main_app.py
from fastapi import FastAPI
import uvicorn

import backend
import ingest_app
import serve_symptom_predict as predict_app

app = FastAPI(title="SAHAS Combined API")

# Mount apps
app.mount("/village-api", backend.app)
app.mount("/ingest", ingest_app.app)
app.mount("/predict", predict_app.app)

@app.get("/")
def root():
    return {"status": "ok", "services": ["village-api", "ingest", "predict"]}

if __name__ == "__main__":
    uvicorn.run("main_app:app", host="0.0.0.0", port=8000, reload=True)
